package Classes;

public enum ItemStatus{
    Defective,
    Expired,
    Available,
    Soldout
}