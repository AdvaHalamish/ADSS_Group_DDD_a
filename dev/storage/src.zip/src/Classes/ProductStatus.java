package Classes;

public enum ProductStatus{
    InStorage,
    NotinStorage
}