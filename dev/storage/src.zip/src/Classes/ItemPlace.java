package Classes;

public enum ItemPlace{
    Store,
    Warehouse,
    delivery,
    Soldout
}